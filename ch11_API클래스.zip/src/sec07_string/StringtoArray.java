package sec07_string;
	
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class StringtoArray {
	
	public static void main(String[] args) {
		String str ="abcd";
		char[] a = str.toCharArray();
		for(int i=0; i<a.length;i++) {
		System.out.println(a[i]);
	}
		
		
//		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//		String[] str2 = br.readLine().split(" ");
//		
//		StringBuilder sb = new StringBuilder();
//		sb.append("adfa"+"\n");
	
	
	
}
	
}
